#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty
import pigpio
import time

class DispenserNode(Node):
    def __init__(self):
        super().__init__('dispenser_node')
        
        self.pi = pigpio.pi()
        if not self.pi.connected:
            self.get_logger().error('pigpiod is not running! Run "sudo pigpiod" first.')
            return

        self.PIN_PUSHER = 18
        self.PIN_DOOR = 19
        self.is_forward = False
        
        # 초기 위치 설정 후 토크 해제
        self.release_all()
        
        self.subscription = self.create_subscription(
            Empty, '/dispenser_trigger', self.trigger_callback, 10)
        
        self.get_logger().info('Dispenser Node Ready (Torque Auto-Release Mode)')

    def release_all(self):
        """모든 서보의 토크를 제거합니다."""
        self.pi.set_servo_pulsewidth(self.PIN_PUSHER, 0)
        self.pi.set_servo_pulsewidth(self.PIN_DOOR, 0)

    def trigger_callback(self, msg):
        self.get_logger().info('Signal Received! Action Start.')
        
        # 1. 문 열림 (Pulse 500)
        self.pi.set_servo_pulsewidth(self.PIN_DOOR, 500)
        time.sleep(0.5)
        self.pi.set_servo_pulsewidth(self.PIN_DOOR, 0)

        if not self.is_forward:
            # 2-A. 푸셔 전진 (Pulse 2400)
            self.pi.set_servo_pulsewidth(self.PIN_PUSHER, 2400)
            time.sleep(0.6)
            self.pi.set_servo_pulsewidth(self.PIN_PUSHER, 0)
            self.is_forward = True
        else:
            # 2-B. 푸셔 후진 (Pulse 600)
            self.pi.set_servo_pulsewidth(self.PIN_PUSHER, 600)
            time.sleep(0.6)
            self.pi.set_servo_pulsewidth(self.PIN_PUSHER, 0)
            self.is_forward = False
        
        # 3. 문 닫힘 (Pulse 1400)
        self.pi.set_servo_pulsewidth(self.PIN_DOOR, 1400)
        time.sleep(0.5)
        self.pi.set_servo_pulsewidth(self.PIN_DOOR, 0)
        
        self.get_logger().info('Sequence Complete & Torque Released.')

def main(args=None):
    rclpy.init(args=args)
    node = DispenserNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.release_all()
        node.pi.stop()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
